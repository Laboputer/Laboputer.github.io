﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myAppLibrary
{
    public class Class1
    {
		public static string GetText()
		{
			return "myAppLibrary.Class1.GetText()";
		}
    }
}
